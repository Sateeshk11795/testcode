﻿using Microsoft.EntityFrameworkCore;
namespace FirstWebCore.Models
{
    public class DataAccess : DbContext
    {
        public DataAccess(DbContextOptions<DataAccess> options): base(options)
        { }

        public DbSet<User> User { get; set; }
    }
}
